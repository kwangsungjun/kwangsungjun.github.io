import numpy as np;
import numpy.random as ra;

#- let's implement the sampling algorithm.

def get_p_l2(q):
    assert q.ndim==1;
    p = (q.astype(np.float64))**2 # p = np.abs(q);
    p /= np.sum(p);
    return p;

def get_p_l1(q):
    assert q.ndim==1;
    p = np.abs(q.astype(np.float64)) # p = np.abs(q);
    p /= np.sum(p);
    return p;

# TODO buggy; if p is 0 somewhere...
def calc_naive(p, m, X, q): # TODO change the order (m to the last)
    """ q: d by 1, X: N by d"""
    assert (p == 0.0).sum() == 0
    cnt = ra.multinomial(m, p);
    return (np.dot(X, cnt * q / p)) / m;

# TODO should I use cython? einsum? some tricks: http://wiki.nmr-relax.com/Numpy_linalg
# TODO masked array?
def calc_v1(p, m, X, q):
    """ q: d by 1, X: N by d"""
    assert (p == 0.0).sum() == 0
    cnt = ra.multinomial(m, p);
    idx = cnt != 0;
    return (np.dot(X[:,idx], cnt[idx] * q[idx] / p[idx] )) / m

def calc_by_l1(m, X, q):
    """ q: d by 1, X: N by d"""
    assert (p == 0.0).sum() == 0
    p = np.abs(q); p /=  p.sum();
    cnt = ra.multinomial(m, p);
    idx = cnt != 0;
    return (np.dot(X[:,idx], cnt[idx] * np.sign(q[idx]) )) / (m / np.sum(np.abs(q)));

#- v1: ensures sampling the part with query.
def qoful_calc_v1(m, projections_all, query, d, p_func):
    """ v2: dimensions for theta_hat are always computed. """
    p = p_func(query[d:,0]);
    assert (p == 0.0).sum() == 0 and len(p) == d**2
    mNew = m-d;
    assert mNew >= 1

    cnt = ra.multinomial(mNew, p);
    idx = np.ones(projections_all.shape[1], dtype=bool);
    idx[d:] = cnt != 0;
    q2 = query.copy();
    q2[:d,0] *= mNew;
    q2[d:,0] *= cnt / p;

    return projections_all[:,idx].dot(q2[idx]) / mNew

def qoful_calc_v1_l1(m, projections_all, query, d):
    return qoful_calc_v1(m, projections_all, query, d, get_p_l1);

def qoful_calc_v1_l2(m, projections_all, query, d):
    return qoful_calc_v1(m, projections_all, query, d, get_p_l2);


def qoful_calc_v2(m, projections_all, query, d, p_func):
    """ v2: dimensions for theta_hat and diagonal of invVt are always computed. """
    mustIdx = np.zeros( d+d**2, dtype=bool);
    mustIdx[:d] = True;
    mustIdx[ range(d,d+d**2,d+1) ] = True;
    p = p_func(query[~mustIdx,0]);
    assert (p == 0.0).sum() == 0
    mNew = m-2*d;
    assert mNew >= 1

    cnt = ra.multinomial(mNew, p); # heavy part...
    idx = np.ones(projections_all.shape[1], dtype=bool);
    idx[~mustIdx] = cnt != 0;   # indexes with nonzero values

    q2 = query.copy();
    q2[mustIdx,0] *= mNew;
    q2[~mustIdx,0] *= cnt / p;

    return projections_all[:,idx].dot(q2[idx]) / mNew

def qoful_calc_v2_l1(m, projections_all, query, d):
    return qoful_calc_v2(m, projections_all, query, d, get_p_l1);

def qoful_calc_v2_l2(m, projections_all, query, d):
    return qoful_calc_v2(m, projections_all, query, d, get_p_l2);

def qoful_calc_v3(m, projections_all, query, d, p_func): 
    """ same as v2, but a bit more efficient"""
    diagRange = np.arange(d,d+d**2,d+1);
    mustIdx = np.zeros( d+d**2, dtype=bool);
    mustIdx[:d] = True;
    mustIdx[ diagRange ] = True;
    non_mustIdx = ~mustIdx;
    non_mustIdx_2 = np.where(non_mustIdx)[0];
    p = p_func(query[non_mustIdx,0]);
    assert (p == 0.0).sum() == 0
    mNew = m-2*d;
    assert mNew >= 1

    idx = np.empty( 2*d + mNew ,dtype=int);
    idx[:d] = np.arange(d);
    idx[d:2*d] = diagRange;
    idx[2*d:] = non_mustIdx_2[ra.choice(len(p),mNew,p=p)]; # need a translation
#    idx.sort(); # I thought it could be faster, but in fact not.

    q2 = query.copy();
    q2[mustIdx,0] *= mNew;
    q2[non_mustIdx,0] /= p;
    return projections_all[:,idx].dot(q2[idx]) / mNew 

def qoful_calc_v3_l1(m, projections_all, query, d):
    return qoful_calc_v3(m, projections_all, query, d, get_p_l1);

def qoful_calc_v3_l2(m, projections_all, query, d):
    return qoful_calc_v3(m, projections_all, query, d, get_p_l2);

#-----
def qoful_calc_obj_v2(m, subX, mat, p):
    cnt = ra.multinomial(m, p);
    idx = cnt >= 1;
    rhs = mat[idx,:] * (cnt[idx] / float(m) / p[idx]).reshape((-1,1));
#    return (np.dot(subX[:,idx], rhs) * subX).sum(1);
    return np.einsum('...i,...i', np.dot(subX[:,idx], rhs), subX);

def qoful_calc_obj_v2_l2(m, subX, mat):
    p = (mat**2).sum(1);
    p /= p.sum();
    return qoful_calc_obj_v2(m, subX, mat, p);

def qoful_calc_obj_v3(m, subX, mat, p_func):
    """ ensure sampling the diagonal of the matrix 
        let k_{1:m} is the sampled index of vec(V), and its row/col index is
        i_{1:m}, j_{1:m}. Then, you compute
             (x[i_{1:m}] .* x[j_{1:m}] .* v[k_{1:m}]).sum()
    """
    d = mat.shape[0];
    m_new = m - d;
    assert m_new >= 1;

    diagRange = np.arange(0,d**2,d+1);
    mustIdx = np.zeros( d**2, dtype=bool);
    mustIdx[ diagRange ] = True;
    non_mustIdx = ~mustIdx;
    non_mustIdx_2 = np.where(non_mustIdx)[0];

    vec = mat.ravel();
    p = p_func(vec[non_mustIdx])
    assert (p == 0.0).sum() == 0

    idx = np.empty( d + m_new ,dtype=int);
    idx[:d] = diagRange;
    idx[d:] = non_mustIdx_2[ra.choice(len(p),m_new,p=p)]; # need a translation
    
    #- now, I need to translate idx into subscripts
    row_idx, col_idx = np.unravel_index(idx, [d,d])
    v = vec.copy();
    v[mustIdx] *= m_new;
    v[non_mustIdx] /= p;
    return ((subX[:,row_idx] * subX[:,col_idx]) * v[idx]).sum(1) / m_new

def qoful_calc_obj_v3_l1(m, subX, mat):
    return qoful_calc_obj_v3(m, subX, mat, get_p_l1);

def qoful_calc_obj_v3_l2(m, subX, mat):
    return qoful_calc_obj_v3(m, subX, mat, get_p_l2);

# def mat_mult_approx(m, p, X, V):
#     cnt = ra.multinomial(m, p);
#     idx = cnt >= 1;
# 
#     rhs = V[idx,:] * (cnt[idx] / float(m) / p[idx]).reshape((-1,1));
#     return (np.dot(X[:,idx], rhs) * X).sum(1);
            






