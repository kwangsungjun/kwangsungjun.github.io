"""
S = 3.0
probit.
d = 20
"""
from kjunutils import *
from bandits import *
import time, numpy as np;
import numpy.random as ra, ipdb, cPickle as pickle, time, scipy.io as sio, numpy.linalg as la;
import warnings,sys,os,copy, pandas as pd;
import cProfile
from expr04_jobtalk_defs import *;

#ra.seed(19);
#algoName = 'oful';
#algoName = 'gloc';
#algoName = 'glocts';
#algoName = 'ol2m';
#algoName = 'glmucb';
#algoName = "uniform";
#algoName = "nn";
#algoName = "nnadaptive";
#algoName = 'ridge';
#algoName = 'svm';
#algoName = 'lr';
#algoName = 'lr-eps';
#algoName = 'lr-us;
algoName = sys.argv[1];

# import os
# algoNameList = ['oful', 'gloc', 'glocts', 'ol2m', 'glmucb', 'uniform', 'nn', 'nnadaptive', 'ridge', 'svm', 'lr', 'lr-eps', 'lr-us'];
# for an in algoNameList:
#     os.system("ipython test_bandit_v2.py " + an);

# import os
# algoNameList = ['oful', 'gloc', 'glocts', 'ol2m', 'glmucb', 'uniform', 'nnadaptive', 'ridge', 'svm', 'lr', 'lr-eps', 'lr-us'];
# for an in algoNameList:
#     os.system("ipython test_bandit_v2.py " + an);

opts = {
    'S': 3.0, # when it is too large, troubles can happen with cvxpy
    'T': 10000,
    'd': 20,
    'N': 200,
    'nTry': 30,
    'useInitIdx': False,
    'gSeed': 219,
    'dataSeed': 199,
    'bArmRemoval': False,
    'glm': GlmProbit, # GlmLogistic, GlmProbit
}
S = opts['S'];
T = opts['T'];
d = opts['d'];
N = opts['N'];
nTry = opts['nTry'];
gSeed = opts['gSeed'];
dataSeed = opts['dataSeed'];

printExpr('opts');

#-----
"""
a trial: draw data, choose the initial point. try all combination of the parameters
"""
printExpr('algoName');
printExpr('gSeed');
ra.seed(gSeed);
printExpr('dataSeed');

# armTsr, rewardTsr : # (nTry) by (#params) by (T)
armTsr = []; rewardTsr = []; 
exptRewardMat = []; # (nTry) by (# of arms)
timeMat = [];
initIdxAry = [];
cumRegretMat = [];
for tryIdx in range(nTry):
    print '';
    print '#'*80;
    print '#----- tryIdx = %5d' % tryIdx;

    data, initIdx = genData(opts, tryIdx);
    printExpr('data.expt_reward[0]');
#     if (opts['glm'] == GlmProbit):
#         data, initIdx = genDataProbit(kjunSeed(dataSeed,tryIdx), d, N, opts['S'],nTry=10)
#     elif (opts['glm'] == GlmLogistic):
#         data, initIdx = genDataLogistic(kjunSeed(dataSeed,tryIdx), d, N, opts['S'],nTry=10)
#     else:
#         raise ValueError();
    
    #--- get the list of parameters 
    grid = banditParamGetGrid_4a(algoName);
    keys, perms = banditParamGetPermutations(grid);
    paramDictList = banditParamGetDictList(keys, perms);

    ra.seed(kjunSeed(gSeed,tryIdx));

    #--- for each parameter tuple
    armMat = nans( (len(paramDictList), T) )
    rewardMat = nans( (len(paramDictList), T) );
    timeAry = [];
    for paramIdx, algoParam in enumerate(paramDictList):
        print '\n#- paramIdx = %5d' % paramIdx;
        printExpr('algoParam');
        algo = banditFactory(algoName, data.X, S, algoParam, opts['glm'], bArmRemoval=opts['bArmRemoval']);

        if (opts['useInitIdx'] == False):
            initIdx = -1;
        
        tt = tic();
        [rewardAry, armAry, dbgDict] = run_bandit(algo, data, T, initIdx=initIdx);
        elapsed = toc(tt);
#        printExpr('rewardAry.sum()');
        cumExpectedRewards = data.expt_reward[armAry].sum();
        cumExpectedRegret = data.get_expected_regret(armAry).sum();
        printExpr('elapsed');
        printExpr('cumExpectedRewards');
        printExpr('cumExpectedRegret');

        armMat[paramIdx,:] = armAry;
        rewardMat[paramIdx,:] = rewardAry;
        timeAry.append( elapsed );

    initIdxAry.append( initIdx );
    armTsr.append( armMat );
    rewardTsr.append( rewardMat );
    exptRewardMat.append( data.expt_reward );
    timeMat.append( timeAry );
    
    #- just to print out some stats
    exptRegretAry = np.max(data.expt_reward) - data.expt_reward;
    cumRegretAry = exptRegretAry[armMat.astype(int)].sum(1);
    
    cumRegretMat.append( cumRegretAry )
    me = np.array(cumRegretMat).mean(0);
    argMin = np.argmin( me );
    print 'current best: multiplier=%g, avg cum regret = %g' % (grid['multiplier'][argMin],me[argMin]);
    pass


varDict = SaveToDict(locals(), ['opts', 'initIdxAry', 'armTsr', 'rewardTsr', 'exptRewardMat', 'timeMat', 'grid', 'keys', 'perms']);
SavePickle('%s-%s.pkl' % (get_time_now_kwang(), algoName), varDict);
