0. requirements
 - python 2.7
 - packages: numpy, cvxpy, matplotlib

1. how to run
(a) (optional) For a quick-run, modify the parameters in run_expr.py so it runs fast.
 - run_expr.py:40, change 'T' from 10000 to 100
 - run_expr.py:45, change 'nTry' from 30 to 2
Here, 'T' is the time horizon and 'nTry' is the number of repeats.

(b) do `python run_expr gloc` and then `python run_expr glmucbli`
 - gloc is our algorithm
 - glmucbli is GLMUCB algorithm from Li et al., 2017; shouldn't be too much different from Filippi et al., 2010.

(c) write down the output file that looks like `20180510Thu-153707-gloc.pkl` and `20180510Thu-153821-glmucbli.pkl` but with different string for time.

(d) edit analyze_expr.py and change:
 - line 13: replace `20180510Thu-153707-gloc.pkl` with the file name from (c) ending with gloc.pkl
 - line 16: replace `20180510Thu-153821-glmucbli.pkl` with the file name from (c) ending with glmucbli.pkl

(e) run `python analyze_expr.py`
 - This will plot various curves, but just look at the first one that shows the curves with the tuned parameters
 - The curve would not make much sense if you followed (a). Now that the code runs, you can try T=10000 and nTry=30 get some meaningful curves.

2. other information
 - expr04_jobtalk_defs.py contains helper functions for run_expr.py
 - bandits.py has the main code for the bandit algorithms
 - kjunutils.py and iprod.py provide some utility functions

