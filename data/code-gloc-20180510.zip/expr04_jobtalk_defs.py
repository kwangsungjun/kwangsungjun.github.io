"""
initiated: 12/21/2017
I am trying to update the experiment for the jobtalk.
"""
from kjunutils import *
from bandits import *
import time, numpy as np;
import numpy.random as ra, ipdb, cPickle as pickle, time, scipy.io as sio, numpy.linalg as la;
import warnings,sys,os,copy, pandas as pd;
import cProfile

def genDataProbit(mySeed, d, N, S, nTry=5):
    rs = ra.RandomState(mySeed);
    data = SphericalProbit(); # TODO
    data.gen_data(d,N,S,rand_stream=rs);
    initIdx = chooseInitPoint_v2(data.expt_reward, nTry=nTry, rand_stream=rs);
    return data, initIdx;

def genDataLogistic(mySeed, d, N, S, nTry=5):
    rs = ra.RandomState(mySeed);
    data = SphericalLogistic();
    data.gen_data(d,N,S,rand_stream=rs);
    # data.gen_data(d, N, posFraction=posFraction, rand_stream=rs);
    # data = SphericalNN();
    # data.gen_data(d, N, posFraction=0.5);
    initIdx = chooseInitPoint_v2(data.expt_reward, nTry=nTry, rand_stream=rs);
    return data, initIdx;

#--- usage
#-  grid = banditParamGetGrid('oful');               # grid[paramName]: the set of parameters to be tested
#-  keys, perms = banditParamGetPermutations(grid);
#-  paramDict = banditParamGetDict(keys, perms, i);
def banditParamGetGrid(algoName):
    paramGrid = {};
#    baseLambdaGrid = 10.0**np.array([-2,-1,0,1,2])
    baseLambdaGrid = np.array([1.]);
#    baseLambdaGridExtended = 10.0**np.array([-4,-3,-2,-1,0,1,2])
    baseLambdaGridExtended = np.array([1.]);
    baseMultiplierGrid = 10.0**np.array([-np.inf, -6,-5,-4,-3,-2,-1,0,1])
    baseExploreUsGrid = np.array([10, 20, 30, 40, 50])
    baseExploreEpsGrid = 10.0**np.array([-3,-2.5, -2, -1.5, -1])

    if (algoName in ["oful", "gloc", "glocts", "ol2m", "ol2mstrip", "glmucbli"]):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = baseMultiplierGrid;
    elif (algoName == "glmucb"):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = 10.0**np.array([-np.inf, -9,-8,-7,-6,-5,-4,-3])
    elif (algoName in ["lts", "ridge", "lr", "svm"]):
        paramGrid['lam'] = baseLambdaGrid;
    elif algoName in ["uniform", "nn", "nnadaptive"]:
        #- nothing to add for now.
        paramGrid['none'] = np.array([np.nan]);
        pass
    elif algoName == 'lr-eps':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreEps'] = baseExploreEpsGrid;
        pass
    elif algoName == 'lr-us':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreUs'] = baseExploreUsGrid;
        pass
    else:
        raise ValueError();

    return paramGrid;

def banditParamGetGrid_time(algoName):
    paramGrid = {};
#    baseLambdaGrid = 10.0**np.array([-2,-1,0,1,2])
    baseLambdaGrid = np.array([1.]);
#    baseLambdaGridExtended = 10.0**np.array([-4,-3,-2,-1,0,1,2])
    baseLambdaGridExtended = np.array([1.]);
    baseMultiplierGrid = 10.0**np.array([-4])

    if (algoName in ["oful", "gloc", "glocts", "ol2m", "ol2mstrip", "glmucbli"]):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = baseMultiplierGrid;
    else:
        raise ValueError();

    return paramGrid;

def banditParamGetGrid_4a(algoName):
    paramGrid = {};
    baseLambdaGrid = np.array([1.]);
    baseMultiplierGrid = 10.0**np.array([-np.inf, -6,-5,-4,-3,-2,-1,0])

    if (algoName in ["oful", "gloc", "glocts", "ol2m", "ol2mstrip", "glmucbli"]):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = baseMultiplierGrid;
    else:
        raise ValueError();

    return paramGrid;

def banditParamGetGrid_3_explore(algoName):
    paramGrid = {};
#    baseLambdaGrid = 10.0**np.array([-2,-1,0,1,2])
    baseLambdaGrid = np.array([1.]);
#    baseLambdaGridExtended = 10.0**np.array([-4,-3,-2,-1,0,1,2])
    baseLambdaGridExtended = np.array([1.]);
    baseMultiplierGrid = 10.0**np.array([-4])
    baseExploreUsGrid = np.array([10, 20, 30, 40, 50])
    baseExploreEpsGrid = 10.0**np.array([-3,-2.5, -2, -1.5, -1])

    if (algoName in ["oful", "gloc", "glocts", "ol2m", "ol2mstrip", "glmucbli"]):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = baseMultiplierGrid;
    elif (algoName == "glmucb"):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = 10.0**np.array([-np.inf, -9,-8,-7,-6,-5,-4,-3])
    elif (algoName in ["lts", "ridge", "lr", "svm"]):
        paramGrid['lam'] = baseLambdaGrid;
    elif algoName in ["uniform", "nn", "nnadaptive"]:
        #- nothing to add for now.
        paramGrid['none'] = np.array([np.nan]);
        pass
    elif algoName == 'lr-eps':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreEps'] = baseExploreEpsGrid;
        pass
    elif algoName == 'lr-us':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreUs'] = baseExploreUsGrid;
        pass
    else:
        raise ValueError();

    return paramGrid;

def banditParamGetGrid_debug(algoName):
    paramGrid = {};
#    baseLambdaGrid = 10.0**np.array([-2,-1,0,1,2])
    baseLambdaGrid = np.array([1.]);
#    baseLambdaGridExtended = 10.0**np.array([-4,-3,-2,-1,0,1,2])
    baseLambdaGridExtended = np.array([1.]);
    baseMultiplierGrid = 10.0**np.array([0]);
    baseExploreUsGrid = np.array([10, 20, 30, 40, 50])
    baseExploreEpsGrid = 10.0**np.array([-3,-2.5, -2, -1.5, -1])

    if (algoName in ["oful", "gloc", "glocts", "ol2m", "glmucb"]):
        paramGrid['lam'] = baseLambdaGrid;
        paramGrid['multiplier'] = baseMultiplierGrid;
    elif (algoName in ["lts", "ridge", "lr", "svm"]):
        paramGrid['lam'] = baseLambdaGrid;
    elif algoName in ["uniform", "nn", "nnadaptive"]:
        #- nothing to add for now.
        paramGrid['none'] = np.array([np.nan]);
        pass
    elif algoName == 'lr-eps':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreEps'] = baseExploreEpsGrid;
        pass
    elif algoName == 'lr-us':
        paramGrid['lam'] = baseLambdaGridExtended;
        paramGrid['exploreUs'] = baseExploreUsGrid;
        pass
    else:
        raise ValueError();

    return paramGrid;

#- a procedure for generating a sequence...
def banditParamGetPermutations(paramGrid):
    sortedKeys = np.sort(paramGrid.keys());
    #- DO RECURSION!!
    valsList = [paramGrid[k] for k in sortedKeys];
    perms = getPermutations(0, valsList);

    return sortedKeys, perms

def banditParamGetDict(keys, perms, i):
    return dict([(keys[j], perms[i][j]) for j in range(len(keys))]);

def banditParamGetDictList(keys, perms):
    return [dict([(keys[j], perms[i][j]) for j in range(len(keys))])
                for i in range(len(perms))];

def getPermutations(level, valsList):
    """
    In : ff(0,[[1,2],[3,4]])
    Out: [[1, 3], [1, 4], [2, 3], [2, 4]]
    """
    # ipdb.set_trace();
    if (level >= len(valsList)):
        return [];
    
    aList = [];
    suffixList = getPermutations(level+1, valsList);
    for v in valsList[level]:
        if (len(suffixList) == 0):
            aList.append( [v] );
        else:
            for suffix in suffixList:
                aList.append( [v] + suffix );
    return aList;
    

def banditFactory(algoName, X, S, algoParam, glm, bArmRemoval=True):
    if (algoName == "oful"):
        raise NotImplementedError();
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'flags':{},
            'R': 0.5,
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
        };
        algo = Oful(**opt);
    elif (algoName == "lts"):
        raise NotImplementedError();
        opt = {
            'X': X,
            'flags':{},
            'R': 0.5,
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
        };
        algo = Lts(**opt);
    elif (algoName == "gloc"):
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'flags':{},
            'R': 0.5,
            'r': 1.0, # smallest norm of an arm 
            'kappa': glm.getKappa(S), 
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'm_t_type': None,
            'calc_radius_version': 3, # 1: problem constant + lambda, 2: just problem constant, 3: full
            'bArmRemoval': bArmRemoval,
        };
        opt.update({
            'next_arm_method': 'gloc', 
            'approx_func': None,    # not being used
            'm_obj': None,          # not being used
            'm_t_type': None,       # not being used
            'subsample_func': None,
            'subsample_rate': 1.0,
        });
        algo = Gloc(**opt);
    elif (algoName == "glocts"):
        raise NotImplementedError();
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'flags':{},
            'R': 0.5,
            'r': 1.0, # smallest norm of an arm 
            'kappa': glm.getKappa(S), 
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'm_t_type': None,
            'calc_radius_version': 3, # 1: problem constant + lambda, 2: just problem constant, 3: full
            'next_arm_method': 'glocts', 
            'm_t_type': 'min_sqrt_eig_fast',
        };
        opt.update({
        });
        algo = Gloc(**opt);
    elif algoName == "ol2m":
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'flags':{},
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'calc_radius_version': 1, # 1: original, 2: just logdet()
            'bArmRemoval': bArmRemoval,
        }
        algo = Ol2m(**opt);
    elif algoName == "ol2mstrip":
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'flags':{},
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'calc_radius_version': 2, # 1: original, 2: just logdet()
            'bArmRemoval': bArmRemoval,
        }
        algo = Ol2m(**opt);
    elif algoName == "glmucb":
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'R': 0.5,
            'kappa': glm.getKappa(S), 
            'flags':{},
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'bArmRemoval': bArmRemoval,
        }
        algo = Glmucb(**opt);
    elif algoName == "glmucbli":
        opt = {
            'X': X,
            'lam': algoParam['lam'],
            'S': S,
            'R': 0.5,
            'kappa': glm.getKappa(S), 
            'flags':{},
            'multiplier': algoParam['multiplier'],  # the multiplier to the radius_sq
            'bArmRemoval': bArmRemoval,
        }
        algo = GlmucbLi(**opt);    
    elif algoName == "uniform":
        raise NotImplementedError();
        opt = {
            'X': X,
        }
        algo = Uniform(**opt);
    elif algoName == "nn":
        raise NotImplementedError();
        opt = {
            'X': X,
            'bAdaptive': False,
        }
        algo = NearestNeighbor(**opt);
    elif algoName == "nnadaptive":
        raise NotImplementedError();
        opt = {
            'X': X,
            'bAdaptive': True,
        }
        algo = NearestNeighbor(**opt);
    elif algoName == "ridge":
        raise NotImplementedError();
        opt = {
            'X': X,
            'algo': 'ridge',
            'paramTup': (algoParam['lam'],),
            'flags': {},
        };
        algo = ScikitBase(**opt);
    elif algoName == "lr":
        raise NotImplementedError();
        opt = {
            'X': X,
            'algo': 'lr',
            'paramTup': (algoParam['lam'],),
            'flags': {},
        };
        algo = ScikitBase(**opt);
    elif algoName == "svm":
        raise NotImplementedError();
        opt = {
            'X': X,
            'algo': 'svm',
            'paramTup': (algoParam['lam'],),
            'flags': {},
        };
        algo = ScikitBase(**opt);
    elif algoName == "lr-eps":
        raise NotImplementedError();
        opt = {
            'X': X,
            'algo': 'lr',
            'paramTup': (algoParam['lam'],),
            'exploreAlgo': 'epsgreedy',
            'exploreParamTup': (algoParam['exploreEps'], ), # 0.05
            'flags': {},
        };
        algo = ScikitBase(**opt);
    elif algoName == "lr-us":
        raise NotImplementedError();
        opt = {
            'X': X,
            'algo': 'lr',
            'paramTup': (algoParam['lam'],),
            'exploreAlgo': 'uncertainty',
            'exploreParamTup': (algoParam['exploreUs'], ), # 20
            'flags': {},
        };
        algo = ScikitBase(**opt);
    else:
        raise ValueError();
    return algo;



def genData(opts, tryIdx):
    dataSeed = opts['dataSeed'];
    d = opts['d'];
    N = opts['N'];
    if (opts['glm'] == GlmProbit):
        data, initIdx = genDataProbit(kjunSeed(dataSeed,tryIdx), d, N, opts['S'],nTry=10)
    elif (opts['glm'] == GlmLogistic):
        data, initIdx = genDataLogistic(kjunSeed(dataSeed,tryIdx), d, N, opts['S'],nTry=10)
    else:
        raise ValueError();

    return data, initIdx;

