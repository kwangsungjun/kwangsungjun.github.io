# -*- coding: utf-8 -*-
from kjunutils import *
from bandits import *
import time, numpy as np;
import numpy.random as ra, ipdb, cPickle as pickle, time, scipy.io as sio, numpy.linalg as la;
import warnings,sys,os,copy, pandas as pd;
import cProfile
from expr04_jobtalk_defs import *;

prefix = './'

fNameDict = {
'gloc'      : '20180510Thu-153707-gloc.pkl',     
# 'ol2m'      : '20171225Mon-223400-ol2m.pkl',   
# 'ol2mstrip' : '20171225Mon-222846-ol2mstrip.pkl',  
'glmucbli'  : '20180510Thu-153821-glmucbli.pkl', 
}
algoNameList = np.sort(fNameDict.keys());

argBestMeanList = [];
argBestMDList = [];
plotDataMean = [];
plotDataMD = [];
plotDataNT = [];
for algoName in algoNameList:
    fName = fNameDict[algoName];
    print '\n### %s' % fName
    dd = LoadPickle(prefix + fName);
    opts = dd['opts'];

    at = np.array(dd['armTsr'],dtype=int); # [tryIdx, paramIdx, T];

    regretTsr = nans(at.shape); #    data.get_expected_regret(armTsr) # [tryIdx, paramIdx, T]; 

    for tryIdx in range(opts['nTry']):
#        ipdb.set_trace();
        data, initIdx = genData(opts, tryIdx);
        regretTsr[tryIdx,:,:] = data.get_expected_regret(at[tryIdx,:,:]); # [paramIdx]
    cumRegretMat = regretTsr.sum(2);

    print 'mean'
    me = cumRegretMat.mean(0)
    dev = getDeviationMat(cumRegretMat.T);
    print 'params: ' + nparray2str(dd['grid']['multiplier'])
    print 'mean(dev): ',
    for v in zip(me,dev):
        print '%g(%g)  ' % (v[0], v[1]),
    print '';
    print 'mean+dev: ' + str(me+dev);

    argBestMean = np.argmin(me);
    argBestMeanList.append( argBestMean );
    print 'best mean    : multiplier=%6g, %g(%g)' % (dd['grid']['multiplier'][argBestMean], me[argBestMean], dev[argBestMean])

    argBestMD = np.argmin(me+dev);
    argBestMDList.append( argBestMD );
    print 'best mean+dev: multiplier=%6g, %g(%g)' % (dd['grid']['multiplier'][argBestMD], me[argBestMD], dev[argBestMD]) 

    tm = np.array(dd['timeMat']);
    print 'time: (mean, min, max) = (%g,%g,%g)' % (tm.mean(), tm.min(), tm.max());
    tm_best = tm[:,argBestMD];
    print 'time of argBestMD: (mean, min, max) = (%g,%g,%g)' % (tm_best.mean(), tm_best.min(), tm_best.max());

    #- plot...
    title = 'Tune by mean'
    tmp = regretTsr[:,argBestMean,:]; # [tryIdx, T]; 
    cumRegretCurve = tmp.cumsum(1);
    me,err = getErrorBarMat(cumRegretCurve.T)
    multiplier = dd['grid']['multiplier'][argBestMean];

    plotDataMean.append( (me,err,multiplier,title) );

    #- plot...
    title = 'Tune by UCB'
    tmp = regretTsr[:,argBestMD,:]; # [tryIdx, T]; 
    cumRegretCurve = tmp.cumsum(1);
    me,err = getErrorBarMat(cumRegretCurve.T)
    multiplier = dd['grid']['multiplier'][argBestMD];

    plotDataMD.append( (me,err,multiplier,title) );

    #- plot...
    title = 'No tuning'
    notuning = -2;
    tmp = regretTsr[:,notuning,:];
    cumRegretCurve = tmp.cumsum(1);
    me,err = getErrorBarMat(cumRegretCurve.T)
    multiplier = dd['grid']['multiplier'][notuning];

    plotDataNT.append( (me,err,multiplier,title) );
    pass

import matplotlib.pyplot as plt;
import colorobject
allColors = colorobject.custom_colorsets.greenarmytage_26;
plt.ion();

colorList = ['red', 'green', 'blue', 'black', 'cyan'];
for (k, plotdata) in enumerate([plotDataMean, plotDataMD, plotDataNT]):
    plt.figure(k);
    nameList = [];
    for (i,v) in enumerate(plotdata):
        me, err, multiplier, title = v;
        color = colorList[i];
        tAry = np.arange(1,len(me)+1);
        plt.plot(tAry, me, color=color, alpha=0.5, linewidth=2);
        plt.fill_between(tAry, me-err, me+err, color=color, alpha=0.15);
        nameList.append( algoNameList[i] + '[%g]'%multiplier );
    plt.legend(nameList);
    plt.title(title);


#- debugging purpose
