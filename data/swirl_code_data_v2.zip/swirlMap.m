function [lambda, alpha, omega, sizeList] = swirlMap(stat, beta0_, gamma0_, taubeta_, taugamma_, initv)
% function [lambda, alpha, omega, sizeList] = swirlMap(stat, beta0_, gamma0_, taubeta_, taugamma_, initv)
%  MAP Parameter estimation for sampling with reduced replacement (SWIRL). Implements section 2.3
%  of Jun et al., 2013.
%
% Input
%
% stat: Matlab structure filled out with prepareEstimation(). See also; prepareEstimaion()
%   stat.a: 
%   stat.b: 
%   stat.C: 
%   stat.n:
%   stat.N:
% beta0_: log(word size) vector from prior knowledge
% gamma0_: log(alpha) scalar from prior knowledge
% taubeta0_: regularizer factor for beta0_
% taugamma0_: regularizer factor for gamma0_
% initv: optional. starting point of the optimization for word size parameter.
% 
% Output
%
% lambda: Poisson parameter for sequence length
% alpha: discount factor
% omega: initial weights of items, normalized to form a probability distribution
% sizeList: unnormalized omega (the use of this is rare).
%
% Reference
%
% Kwang-Sung Jun, Xiaojin Zhu, Burr Settles, and Timothy Rogers. Learning from Human-Generated 
% Lists. In The 30th International Conference on Machine Learning (ICML), 2013.
%
% Author
%
% Original: Jerry Zhu, July 2012
% modified: Kwang-Sung Jun, Sep 2012

global a b C n N beta0 gamma0 taubeta taugamma;
a = stat.a;
b = stat.b;
C = stat.C;
n = stat.n;
N = stat.N;
beta0 = ensureColVec(beta0_);
gamma0 = gamma0_;
taubeta = taubeta_;
taugamma = taugamma_;

nvoc = length(b);

% The MLE Poisson parameter for sequence length is simply the sample mean
lambda = stat.lambda;

% note b is the negative vocabulary count vector
% we find the most frequent word type (MFW) and later constrain omega(MFW)=1, equivalently x(MFW)=0
[negmfwcount MFW] = min(b);

if (exist('initv','var') && ~isempty(initv))
  initv = reshape(initv, length(initv), 1);
  v0 = initv;
else
  v0 = [0; zeros(nvoc,1)]; % initial point: alpha=1, omega= all 1.
end

options = optimset('Algorithm', 'active-set', 'GradObj','on', 'DerivativeCheck', 'off', ...
  'TolFun', 1e-12, 'Display', 'off', ...
  'MaxFunEvals',  4000, 'MaxIter', 4000);

% FIXME: for debugging
% options.Display = 'iter';

obj = @(v) swirlMapObj(v, a, b, C, n, N, beta0, gamma0, taubeta, taugamma);

lb = -inf(1,nvoc+1);
ub = inf(1,nvoc+1); ub(1) = 0; % variable bound constraint: y<=0 so that alpha<=1
[v,fval,exitflag,output, ~, grad] = fmincon(obj, v0, [], [], [], [], lb, ub, [], options);

alpha = exp(v(1));
omega = exp(v(2:end));
sizeList = omega;
omega = omega/sum(omega);

clear global a b C n N beta0 gamma0 taubeta taugamma;

end
