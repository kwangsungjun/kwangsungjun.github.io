function [Z, vocaList] = parseFromStructForMap(dset, varName, subjectTypeIdx)
% Converts data into a convenient matrix Z where Z(j,i) is the word index of j'th list i'th poisition.
% zeros are padded in Z to mark the end of each list. This function also makes sure that the
% special vocabulary UNKNOWN is instantiated to a unique vocabulary for each occurrence.
% Any words that do not appear in given 'subjectTypeIdx' are NOT deleted from the vocaList.
%
% Author
%
% Kwang-Sung Jun, Sep 2012


% load word lists
mat = eval(['dset.' varName]);

% this is to find vocabulary shared by both subjectTypes
subjIdx1 = (dset.subjectTypes == 1);
subjIdx2 = (dset.subjectTypes == 2);

fullZ = mat(subjIdx1 | subjIdx2,:);
reducedSubjectTypes = dset.subjectTypes(subjIdx1 | subjIdx2);

vocaList = dset.vocaList;

% find out `UNKNOWN` and assign unique word
assert(strcmp(vocaList{1}, 'UNKNOWN') == 1);
maxIdx = length(vocaList);
cnt = 1;
for i=1:size(fullZ,1)
  for j=1:size(fullZ,2)
    if (fullZ(i,j) == 1)
      fullZ(i,j) = maxIdx + cnt;
      vocaList{end+1} = sprintf('UNKNOWN%03d', cnt);
      cnt = cnt + 1; 
    end
  end
end

uniqueIndices = unique(fullZ(:));
uniqueIndices = uniqueIndices(uniqueIndices ~= 0);

idxMap = containers.Map(uniqueIndices, 1:length(uniqueIndices));

%
for i=1:size(fullZ,1)
  for j=1:size(fullZ,2)
    if (fullZ(i,j) ~= 0)
      fullZ(i,j) = idxMap(fullZ(i,j));
    end
  end
end

idx = reducedSubjectTypes == subjectTypeIdx;
Z = sparse(fullZ(idx,:));
vocaList = vocaList(uniqueIndices);

end