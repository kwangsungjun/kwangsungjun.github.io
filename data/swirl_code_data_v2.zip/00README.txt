RELEASE NOTES
----------------------

Version 1.0
June  17, 2013

----------------------
Data Use Agreement

No Warranties. I understand that the Data is made available free of charge
by Professor Xiaojin Zhu as a courtesy to the research community. I
understand and accept that this data is provided as-is, with no warranties
of any kind, including but not limited to warranties of fitness for a
particular purpose or warranties of non-infringement.

Liability. I agree to be responsible for any and all liability arising
from my use of the Data, and to hold Professor Xiaojin Zhu and the
University of Wisconsin-Madison harmless from any such liability. I
further agree to comply with all applicable laws and regulations in the
use of the Data.

Notification of Publication or Presentation of Data. I agree to notify
Professor Xiaojin Zhu at jerryzhu@cs.wisc.edu at the time of any
publication or presentation using the data from this site.

Acknowledgment of Source of Data. I agree to cite or acknowledge Professor
Xiaojin Zhu and the University of Wisconsin-Madison as the source of data
in any such publication or presentation.

Transfer. I agree that I will not share or transfer the Data obtained from
this site to any other person, and I will refer any requests for such Data
to Professor Zhu (jerryzhu@cs.wisc.edu).
---------------------------

Release compiled by Kwang-Sung Jun (deltakam@cs.wisc.edu)
06/17/13


#- Contents -------------------------------------------------------------------
#
# 0. Introduction
# 1. Included Files
# 2. Data Description in Detail
#   2.1 Feature Volunteering
#------------------------------------------------------------------------------

0. Introduction

  This is data used and described in the paper:

  Kwang-Sung Jun, Xiaojin Zhu, Burr Settles, and Timothy Rogers. Learning from
  Human-Generated Lists. In The 30th International Conference on Machine
  Learning (ICML), 2013.
  http://pages.cs.wisc.edu/~jerryzhu/pub/SWIRL.pdf 
  (In case of broken URL, find it from publication page at 
  http://pages.cs.wisc.edu/~jerryzhu)

  Note that this package contains feature volunteering data, but not verbal 
  fluency data because it is a private data.

  The main function for learning MLE of SWIRL is swirlMle.m. The function takes
  in a matrix Z, which is the input set of lists, and returns estimated
  parameters.  Type in "help swirlMle" in Matlab (or open swirlMle.m) to see
  input and output specification.

  Another main function for learning MAP of SWIRL is swirlMap.m. Type in 
  "help swirlMap" in Matlab (or open swirlMle.m) to see input and output 
  specification.                                                               

  For a quick test run, type the script file "test_featurevolunteering_mle" in
  Matlab.


1. Included Files
  
  |-FeatureVolunteering/
  | `-v1/
  |   |-movie/
  |   | |-data.txt           : Volunteered feature lists for
  |   | |                      movie domain in Section 3.5 in Jun et al.,
  |   | |                      2013
  |   | |-label.txt          : Label description for data.txt
  |   | |-voca.txt           : Vocabulary description for data.txt
  |   | `-dataset.mat        : Off-the-shelf MATLAB data file
  |   |                        containing all three files above
  |   |-sports/
  |   | |-data.txt           : Volunteered feature lists for
  |   | |                      sports domain in Section 3.5 in Jun et 
  |   | |                      al., 2013
  |   | |-label.txt          : Label description for data.txt
  |   | |-voca.txt           : Vocabulary description for data.txt
  |   | `-dataset.mat        : Off-the-shelf MATLAB data file
  |   |                        containing all three files above
  |   `-webkb/
  |     |-data.txt           : Volunteered feature lists for
  |     |                      webkb domain in Section 3.5 in Jun et 
  |     |                      al., 2013
  |     |-label.txt          : Label description for data.txt
  |     |-voca.txt           : Vocabulary description for data.txt
  |     `-dataset.mat        : Off-the-shelf MATLAB data file
  |                            containing all three files above
  |-ensuerColVec.m           : make any vector a column vector
  |-logsumexp.m              : compute log(sum(exp(v))) without overflow
  |-parseFrom.m              : preprocess for SWIRL MLE for patient data
  |-parseFromStructForMap.m  : preprocess for SWIRL MAP for patient data
  |-prepareEstimation.m      : precomputes constants used for objective function
  |-printVoca.m              : prints out vocabulary and weight neatly
  |-swirlMle.m               : finds SWIRL MLE given data
  |-swirlMap.m               : finds SWIRL MAP given data
  |-swirlMapObj.m            : SWIRL MAP objective function
  |-test_featurevolunteering_mle.m : example script for SWIRL MLE for feature
  |                            volunteering data
  |-test_featurevolunteering_map.m : example script for SWIRL MAP for feature
  |                            volunteering data                  
  `-00README.txt             : this file


2. Data Description in detail

  2.1 Feature Volunteering
    There are three domains: movie, sports, and webkb. Data was collected
    using a web interface where each subject repeatedly generates
    phrase=>label rules. The time stamp at each input is also recorded.
    Note, however, that the time stamp was ignored in the paper.
    See Jun et al., 2013 for detail.
    
    For each domain, there are data.txt, label.txt, voca.txt, and dataset.mat.

    * data.txt
    ---------
    [subject index]|[label index]:[phrase index] [label index]:[phrase index] ...
    [subject index]|[time in milliseconds] [time in milliseconds] ...
    [subject index]|[label index]:[phrase index] [label index]:[phrase index] ...
    [subject index]|[time in milliseconds] [time in milliseconds] ...
    ...
    ---------
    The total number of lines is the number of subjects divided by 2 since each
    pair of lines represents a list produced by a single subject. In the first
    line [label index]:[phrase index] represents "phrase=>label" rule, and the
    same column in the second line contains the time stamp of the rule. Each
    time stamp measures milliseconds that have passed since the time the user is
    presented with the list generation task.

    * label.txt
    ---------
    [label index] [label description]
    [label index] [label description]
    ...
    ---------
    This file contains description on class labels that appear in data.txt

    * voca.txt
    ---------
    [phrase index] [phrase]
    [phrase index] [phrase]
    ...
    ---------
    This file contains actual phrases that appear in data.txt along with  phrase
    indices.
    
    * dataset.mat
    Note that since Matlab has 1-based arrays, the lowest index for label,
    phrase, and subject is now adjusted to 1, unlike .txt files above. In other
    words, all indices appeared in .txt files above are shifted by +1.
    This file contains the following variables:
     - labelList: a cell variable where labelList{i} is the string description
       of label index i.
     - labelMat: a matrix variable where labelMat(i,j) is the label index of
       j'th rule in i'th list and 0 when there is no more items in the list.
     - wordMat: a matrix variable where wordMat(i,j) is the phrase index of
       j'th rule in i'th list and 0 when there is no more items in the list.
     - timeMat: a matrix variable where timeMat(i,j) is the time stamp of
       j'th rule in i'th list and 0 when there is no more items in the list. 
     - vocaList: cell variable where vocaList{i} is the phrase string of phrase
       index i.

* Reference
Kwang-Sung Jun, Xiaojin Zhu, Burr Settles, and Timothy Rogers. Learning from
Human-Generated Lists. In The 30th International Conference on Machine
Learning (ICML), 2013.

