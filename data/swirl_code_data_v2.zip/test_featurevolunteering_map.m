clear all;
sportsFileName = 'FeatureVolunteering/v1/sports/dataset.mat';
movieFileName = 'FeatureVolunteering/v1/movie/dataset.mat';
webkbFileName = 'FeatureVolunteering/v1/webkb/dataset.mat';

sportsData = load(sportsFileName);
movieData = load(movieFileName);
webkbData = load(webkbFileName);

% FIXME: choose taskNum \in {1,2,3}
taskNum = 2;
taskNames = {'sports', 'movie', 'webkb'};
tasks = {sportsData, movieData, webkbData};
dset = tasks{taskNum};

res = struct();
for class=1:length(dset.labelList)
  [Z, vocaList] = parseSportsMovieWebkb(dset, class);
  
  nvoc = length(vocaList);
  taubeta = 1;
  taugamma = 1;
  beta0 = zeros(nvoc,1); 
  gamma0 = 0;

  stat = prepareEstimation(Z, nvoc);
  [hatlambda, hatalpha, hatomega, sizeList] = ...
    swirlMap(stat, beta0, gamma0, taubeta, taugamma, []);

  res(class).className = dset.labelList{class};
  res(class).Z = Z;
  res(class).vocaList = vocaList;
  res(class).hatlambda = hatlambda;
  res(class).hatalpha = hatalpha;
  res(class).hatomega = hatomega;
  res(class).sizeList = sizeList;
end

for i=1:length(res)
  fprintf('##-- Task: %s, %s\n', taskNames{taskNum}, res(i).className);
  fprintf('hatlambda = %f\n', res(i).hatlambda);
  fprintf('hatalpha = %f\n', res(i).hatalpha);
  printVoca(res(i).vocaList, res(i).hatomega);
  fprintf('\n');
end
