function [Z, vocaList] = parseFrom(matFileName, varName, subjectTypeIdx)
% Converts data into a convenient matrix Z where Z(j,i) is the word index of j'th list i'th poisition.
% zeros are padded in Z to mark the end of each list. This function also makes sure that the
% special vocabulary UNKNOWN is instantiated to a unique vocabulary for each occurrence.
% Any words that do not appear in given 'subjectTypeIdx' are deleted from the vocaList
%
% Author
%
% Kwang-Sung Jun, Sep 2012


% it also takes care of UNKNOWN vocabulary
dset = load(matFileName);
mat = eval(['dset.' varName]);

ridx = dset.subjectTypes == subjectTypeIdx;
fullZ = mat(ridx,:);

vocaList = dset.vocaList;

% find out `UNKNOWN` and assign unique word
assert(strcmp(vocaList{1}, 'UNKNOWN') == 1);
maxIdx = length(vocaList);
cnt = 1;
for i=1:size(fullZ,1)
  for j=1:size(fullZ,2)
    if (fullZ(i,j) == 1)
      fullZ(i,j) = maxIdx + cnt;
      vocaList{end+1} = sprintf('UNKNOWN%03d', cnt);
      cnt = cnt + 1; 
    end
  end
end

uniqueIndices = unique(fullZ(:));
uniqueIndices = uniqueIndices(uniqueIndices ~= 0); % zeros are just for padding.

%
idxMap = containers.Map(uniqueIndices, 1:length(uniqueIndices));

%
for i=1:size(fullZ,1)
  for j=1:size(fullZ,2)
    if (fullZ(i,j) ~= 0)
      fullZ(i,j) = idxMap(fullZ(i,j));
    end
  end
end


Z = sparse(fullZ);
vocaList = vocaList(uniqueIndices);

end