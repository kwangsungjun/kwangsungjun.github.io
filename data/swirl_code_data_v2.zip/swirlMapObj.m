function [f, g] = swirlMapObj(v, a, b, C, n, N, beta0, gamma0, taubeta, taugamma)
% function [f, g] = swirlMapObj(v, a, b, C, n, N, beta0, gamma0, taubeta, taugamma)
%  MAP Parameter estimation objective function for sampling with reduced replacement (SWIRL). 
%  Implements section 2.3 of Jun et al., 2013.
%
% Input
%
% v: vector at which the function is evaluated. v(1) is \gamma, and v(2:end) is \beta in the paper.
% a, b, C, n, N: these constants should already be computed by prepareEstimation.m
% beta0: log(word size) vector from prior knowledge
% gamma0: log(alpha) scalar from prior knowledge
% taubeta0: regularizer factor for beta0_
% taugamma0: regularizer factor for gamma0_
% 
% Output
%
% f: function value
% g: derivative at v
%
% Reference
%
% Kwang-Sung Jun, Xiaojin Zhu, Burr Settles, and Timothy Rogers. Learning from Human-Generated 
% Lists. In The 30th International Conference on Machine Learning (ICML), 2013.
%
% Author
%
% Original: Jerry Zhu, July 2012
% modified: Kwang-Sung Jun, Sep 2012

y=v(1); x=v(2:end);
f = a*y + b'*x;
partialy = a;
partialx = b;
for j=1:N,
  for i=1:n(j);
    vv = C{j}(:,i)*y + x;
    discounted = exp(vv); % discounted omega
    normalizer = sum(discounted);
    f = f + logsumexp(vv);
    partialy = partialy + discounted'*C{j}(:,i)/normalizer;
    partialx = partialx + discounted/normalizer;
  end
end

% add regularizers to f
f = f + taubeta*sum((x-beta0).^2) + taugamma*((y-gamma0)^2);

% add regularizers to g
partialy = partialy + taugamma*2*(y-gamma0);
partialx = partialx + taubeta.*2.*(x-beta0);

g = [partialy; partialx]; % the gradient

end