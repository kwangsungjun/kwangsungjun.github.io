function [Z, vocaList] = parseSportsMovieWebkb(dset, class)
% function [Z, vocaList] = parseSportsMovieWebkb(dset, class)
%  This function extracts sublist from a list of 'word=>class' rules.
%
% Author
%
% Kwang-Sung Jun, Sep 2012

% only pick those of `class`
maxLen = max(sum(dset.labelMat == class,2));

Z = zeros(0,maxLen);
for i=1:size(dset.wordMat,1)
  indices = dset.labelMat(i,:) == class;
  v = dset.wordMat(i,indices);

  % do not process empty list
  if (~isempty(v))
    Z(end+1,1:length(v)) = v;
  end
end

% reduce voca so we only have words that actually appear in the class.
uniqueWords = unique(Z);
uniqueWords = uniqueWords(uniqueWords ~= 0); % remove 0 since it is just padding

idxMap = containers.Map(uniqueWords, 1:length(uniqueWords));

% update word indices.
for i=1:size(Z,1)
  for j=1:size(Z,2)
    if (Z(i,j) ~= 0)
      Z(i,j) = idxMap(Z(i,j));
    end
  end
end

vocaList = dset.vocaList(uniqueWords);
Z = sparse(Z);

end
