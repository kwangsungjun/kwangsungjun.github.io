function printVoca(vocaList, w, topN)
% prints out vocabulary and its weight

[~,sidx] = sort(w, 'descend');
w = w(sidx);
wIdx = 1:length(w);
wIdx = wIdx(sidx);

if (~exist('topN'))
  topN = inf;
end

maxx = min(length(w), topN);
for i=1:maxx
  idx = wIdx(i);
  weight = w(i);
  
  fprintf('%20s\t%10.4f\n',vocaList{idx} , weight);
end

end

